# FLOLAC 2018 分享：Racket, 程式語言導向的程式設計

這個目錄包含了投影片以及範例程式碼。
要啟動投影片，在當前目錄執行 `racket slide.rkt` 即可。
如果有缺函式庫，可以當前目錄執行 `raco pkg install` 安裝
相關的 dependencies。

大部分的範例程式碼都在 `examples/` 目錄中，唯一的例外
是演示 macro 展開過程的範例程式碼，`gen-expansion-steps.rkt`。

- `dsl-intro.rkt` 裡是投影片一開始展示的程式碼。
  這份單一語言的程式碼使用了許多 eDSL 包括
  contracts、submodules、`syntax/parse` 和 syntax templates，
  最後並給了一個 transformer (macro) 的範例。

- `contract-example.rkt` 是展示 contract system 的範例程式。

- `provide-require.rkt` 則是 provide-require eDSL 的例子。

- `macro-simple.rkt` 示範了 macros 並給出一個會追蹤函數呼叫
  的巨集。

- `data-enumerate.rkt` 和 `redex-lambda.rkt` 裡面分別包含了
  兩種不同的 eDSL，前者用來描述「如何枚舉資料」而後者用來
  撰寫、執行、測試及實驗程式語言的模型。

- `keyword-example.rkt` 想要表達 keyword argument protocol
  也是一個獨立的 eDSL，並且在更底層的語言像 `'#%kernel` 中
  是不支援的。

- `gen-expansion-steps.rkt` 執行後會印出一個模組做 macro
  展開的部分過程。其中有些特殊的步驟會插入 `#%datum`、`#%top`、
  `#%app`、`#%module-begin` 等 special forms 讓語言實作者能夠實作
  不同的語義。

- `algol60-demo.rkt`、`typed-racket.rkt` 是兩個在 Racket
  中實作的完全不同的語言的例子。其中 ALGOL 語義、語法都與
  Racket 相異，而 Typed Racket 則是靜態型別語言。

- `untypd.rkt` 以及 `vec.rkt` 是介紹不同語言互動的範例程式。

- `log-eval.rkt` 演示編譯的行為甚至模組載入的行為都是可程式化的。
  這個檔案裡面提供了會印出 "正在編譯的算式" 的編譯器以及
  會印出模組路徑的載入器。直接執行 `racket examples/log-eval.rkt`
  可以看到結果。
