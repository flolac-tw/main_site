module Properties where

-- Code adapted from Chris Okasaki,
--  Red-black trees in a functional setting.
--  Journal of Functional Programming, 9(4):471–477, 1999.

import Base

isRedBlackTree :: RBTree Int -> Bool
isRedBlackTree t = isSorted t && isBalanced t && isRB t

-- height

bheight :: RBTree a -> Nat
bheight E = 0
bheight (R t x u) = bheight t `max` bheight u
bheight (B t x u) = 1 + (bheight t `max` bheight u)

isBalanced :: RBTree a -> Bool
isBalanced E = True
isBalanced (R t x u) = undefined
isBalanced (B t x u) = undefined

-- sortedness

maxRBT :: RBTree Int -> Int
maxRBT E = minBound
maxRBT (R t x u) = undefined
maxRBT (B t x u) = undefined

minRBT :: RBTree Int -> Int
minRBT E = maxBound
minRBT (R t x u) = undefined
minRBT (B t x u) = undefined

isSorted :: RBTree Int -> Bool
isSorted E = True
isSorted (R t x u) = undefined
isSorted (B t x u) = undefined

-- colors

isSemiRB :: RBTree a -> Bool
isSemiRB E = True
isSemiRB (B t x u) = undefined
isSemiRB (R t x u) = undefined

isRB :: RBTree a -> Bool
isRB t = color t == Blk && isSemiRB t

  -- infrared

isIRB :: RBTree a -> Bool
isIRB (R t x u) = (color t == Blk || color u == Blk) &&
                    isSemiRB t && isSemiRB u
isIRB _         = False

-- checkable properties.

-- To test these properties, type for example,
--   > quickCheck propIsBalanced
-- in GHCi.
-- To see the inputs used in testing, use
--   > verboseCheck propIsBalanced

propIsBalanced :: [Int] -> Bool
propIsBalanced = isBalanced . build

propIsSorted :: [Int] -> Bool
propIsSorted = isSorted . build

propIsRB :: [Int] -> Bool
propIsRB = isRB . build

propIsRB' :: Int -> [Int] -> Bool   -- would be falisified
propIsRB' x xs = isRB . ins x . build $ xs

propIsIRB :: Int -> [Int] -> Bool
propIsIRB x xs = isIRB . ins x . build $ xs
