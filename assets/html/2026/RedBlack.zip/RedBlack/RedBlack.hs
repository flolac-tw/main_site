{-# LANGUAGE StandaloneDeriving #-}
module RedBlack where

-- Code adapted from Chris Okasaki,
--  Red-black trees in a functional setting.
--  Journal of Functional Programming, 9(4):471–477, 1999.

-- Uncomment the next line if you manage to have QuickCheck installed.
-- import Test.QuickCheck

import Base
import Properties
import Render
import Proofs
