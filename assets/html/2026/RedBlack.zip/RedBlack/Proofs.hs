module Proofs where

import Base
import Properties
import Base
import qualified Base as Proof


-- 1. Prove that bheight (ins k t) = bheight t for all k and t.
-- Proof.
-- By induction on t.
-- Case t := E

bheightInsBase k = undefined

-- Case t := R t x u, k < x
bheightInsIndR k t x u = undefined

-- Case t := B t x u, k < x
bheightInsIndB k t x u = undefined

-- Assumption:
--    bheight (rotate t x u) = ... ?
-- Proof.
-- Case

bheightRotateCase1 = undefined

-- 2. Prove that isBalanced t ==> isBalanced (insert x t).

-- 3. Prove that
{-
(isSemiRB t && color t == Red  ==> isIRB (ins x t)) &&
(isSemiRB t && color t == Blk  ==> isSemiRB (ins x t))
-}


---
infixr 0 ===

(===) :: a -> List a -> List a
(===) = (:)

qed :: List a
qed = []
