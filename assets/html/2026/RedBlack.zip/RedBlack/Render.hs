module Render where

import Base

type DStr = String -> String

render :: Show a => RBTree a -> IO ()
render t = putStr (joinLines (drawRB t) "")

joinLines :: [DStr] -> DStr
joinLines = foldr (\f g -> f . ('\n':) . g) id

drawRB :: Show a => RBTree a -> [DStr]
drawRB E = [('E':)]
drawRB (R E x E) = [("R [" ++) . (show x ++) . ("] "++)]
drawRB (B E x E) = [("B [" ++) . (show x ++) . ("] "++)]
drawRB (R t x u) = drawNode Red t x u
drawRB (B t x u) = drawNode Blk t x u

drawNode :: Show a => Color -> RBTree a -> a -> RBTree a -> [DStr]
drawNode c t x u =
   ((((hd ++) . (sx ++) . (" ┬ "++)) : repeat indentBar) <+> drawRB u) ++
   (((spaces (3+n)       . ("└ " ++)) : repeat indent   ) <+> drawRB t)
 where hd = case c of { Red -> "R "; Blk -> "B " }
       sx = show x
       n  = length sx
       indentBar = spaces (3+n) . ("│ "++)
       indent    = spaces (5+n)

(<+>) :: [DStr] -> [DStr] -> [DStr]
(<+>) = zipWith (.)

spaces :: Int -> DStr
spaces n = (replicate n ' ' ++)
