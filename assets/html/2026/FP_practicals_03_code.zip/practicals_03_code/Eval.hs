import Prelude ()
import MiniPrelude
import Monads

data Expr = Num Int | Neg Expr | Add Expr Expr
          | Var Name | Let Name Expr Expr

type Name = String

type Env = List (Name, Int)
-- What if we define
-- type Env = Name -> Maybe Int   -- ?

-- The function
--   lookup :: Eq a => a -> List (a, b) -> Maybe b
-- is defined in GHC.List and imported here.

-- What should the type of eval be?
-- You can leave it commented for now, and let Haskell derive the type.
-- eval :: Expr -> ???
eval (Num n) = undefined
eval (Neg e) = undefined
eval (Add e0 e1) = undefined
eval (Var x) = undefined
eval (Let x e0 e1) = undefined


-- operations on environment
-- What if we define type Env = Name -> Maybe Int ?

empty :: Env
empty = []

extend :: (Name, Int) -> Env -> Env
extend (x,v) env = (x,v) : env

-- exceptions/errors

data Err = DivByZero | VarNotFound Name
  deriving Show

{-
Additional information: you might think using (>>=) or the do-notation
makes the code lengthy and too "imperative" in style. I agree.

For monad m, we have the following operators:

  (<$>) :: (a -> b) -> m a -> m b
  (<*>) :: m (a -> b) -> m a -> m b

Trying using these operators instead of (>>=) or do, when possible.

These operators actually belongs to a concept called
"applicative functors", but we won't talk about them in this course.
-}

tstExpr00 :: Expr
tstExpr00 = Let "x" (Num 3)
             (Add (Add (Var "x") (Let "x" (Num 4) (Var "x")))
                  (Neg (Var "x")))

tstExpr01 :: Expr
tstExpr01 = Let "x" (Add (Num 3) (Num 4))
             (Let "y" (Add (Var "x") (Neg (Num 1)))
                (Add (Add (Neg (Var "y")) (Var "x")) (Var "x")))

{-
tstExpr02, tstExpr03 :: Expr

tstExpr02 = (Num 65536 `Add` Num 32768) `Div`
                (Num 1 `Add` Num 65536)

tstExpr03 = (Num 32768 `Div` Num 0) `Add` Num 32768

-}
