\begin{code}
module Proofs where

import Base
import Properties
import Base
import qualified Base as Proof
\end{code}

1. Prove that bheight (ins k t) = bheight t for all k and t.

Proof.

By induction on t.

Case t := E:

\begin{code}
bheightInsBase k =
      bheight (ins k E)
 ===  bheight (R E k E)
 ===  0
 ===  bheight E
 ===  qed
\end{code}

Case t := R t x u, k < x
\begin{code}
bheightInsIndR k t x u =
      bheight (ins k (R t x u))
 ===    {- definition of ins, with k < x -}
      bheight (R (ins k t) x u)
 ===    {- definition of bheight -}
      bheight (ins k t) `max` bheight u
 ===    {- induction -}
      bheight t `max` bheight u
 ===    {- definition of bheight -}
      bheight (R t x u)
 ===  qed
\end{code}

Case t := B t x u, k < x
\begin{code}
bheightInsIndB k t x u =
      bheight (ins k (B t x u))
 ===    {- definition of ins, with k < x  -}
      bheight (rotate (ins k t) x u)
 ===    {- Lemma below -}
      1 + (bheight (ins k t) `max` bheight u)
 ===    {- induction -}
      1 + (bheight t `max` bheight u)
 ===    {- definition of bheight -}
      bheight (B t x u)
 ===  qed
\end{code}

For the proof to go through, by observing the expression we realise
that we may want the following property about bheight and rotate:

  For all t, u and z,

    bheight (rotate t z u) = 1 + (bheight t `max` bheight u)

Note that bheight is not recursive, and the proof of the property
merely involves checking all the cases. we check a representative case:

Case (t,z,u) := (R (R t x u) y v, z, w):
\begin{code}
bheightRotateRR t x u y v z w =
   bheight (rotate (R (R t x u) y v) z w)
 ===    {- definition of rotate -}
   bheight (R (B t x u) y (B v z w))
 ===    {- definition of bheight -}
   (1+ (bheight t `max` bheight u)) `max` (1+ (bheight v `max` bheight w))
 ===    {- since (k+x) `max` (k+y) = k + (x `max` y), max associative -}
   1 + (((bheight t `max` bheight u) `max` bheight v) `max` bheight w)
 ===    {- definition of bheight -}
   1 + (bheight ((R (R t x u) y v)) `max` bheight w)
 === qed
\end{code}


2. Prove that isBalanced t ==> isBalanced (insert x t).

Proof. Induction on t.
The case for t := E is easy. We look at only one representative case.

Case t := B t x u, k < x.

\begin{code}
isBalancedInd k t x u =
      isBalanced (ins k (B t x u))
 ===    {- definition of ins, k < x -}
      isBalanced (rotate (ins k t) x u)
 <==    {- property about isBalanced and rotate  -}
      isBalanced (ins k t) && isBalanced u && bheight (ins k t) == bheight u
 ===    {- property about bheight above -}
      isBalanced (ins k t) && isBalanced u && bheight t == bheight u
 <==    {- induction -}
      isBalanced t && isBalanced u && bheight t == bheight u
 ===    {- definition of |isBalanced| -}
      isBalanced (B t x u)
 === qed
\end{code}

We need a property about isBalanced and rotate, namely,

 isBalanced t && isBalanced u &&
   bheight t = bheight u ==> isBalanced (rotate t x u)

I can be proved by induction. We present only one inductive case.
\begin{code}
balancedRotate k t x u y v z w =
    isBalanced (rotate (R (R t x u) y v) z w)
 ===    {- definition of |rotate| -}
    isBalanced (R (B t x u) y (B v z w))
 ===    {- definition of |balanced| -}
    bheight (B t x u) == bheight (B v z w) &&
    isBalanced (B t x u) && isBalanced (B v z w)
 ===    {- definition of |bheight| -}
    1 + (bheight t `max` bheight u) == 1+ (bheight v `max` bheight w) &&
    bheight t == bheight u && isBalanced t && isBalanced u &&
    bheight v == bheight w && isBalanced v && isBalanced w
 <==  {- definitions of |balanced| and |bheight|, arithmetics-}
    bheight (R t x u) == bheight v &&
    isBalanced (R t x u) && isBalanced v && isBalanced w &&
    bheight t `max` bheight u `max` bheight v == bheight w
 ===    {- definitions of |balanced| 與 |bheight| -}
    isBalanced (R (R t x u) y v) && isBalanced w &&
      bheight (R (R t x u) y v) == bheight w
 === qed
\end{code}

3. Prove that

  (isSemiRB t && color t == Red  ==> isIRB (ins x t)) &&
  (isSemiRB t && color t == Blk  ==> isSemiRB (ins x t))  -- (1)


Proof by induction on t.
We present only two representative cases.

Note that, since a tree is either Red or Black, (1) implies

  isSemiRB t ==> isIRB (ins x t) || isSemiRB (ins x t))  -- (2)

Case t := B t x u, k < x.
\begin{code}
semiRBInsInd1 k t x u =
   isSemiRB (ins k (B t x u))
 ===    {- definition of ins, k < x -}
   isSemiRB (rotate (ins k t) x u)
 <==    {- property of isSemiRB and rotate, see below -}
   (isIRB (ins k t) || isSemiRB (ins k t)) && isSemiRB u
 <==    {- induction, (2) -}
   isSemiRB t && isSemiRB u
 ===    {- definition of isSemiRB -}
   isSemiRB (B t x u)
 === qed
\end{code}

Case t := R t x u, k < x.
\begin{code}
semiRBInsInd2 k t x u =
   isIRB (ins k (R t x u))
 ===    {- definition of ins-}
   isIRB (R (ins k t) x u)
 ===    {- definition of isIRB -}
   (color (ins k t) == Blk || color u == Blk) && isSemiRB (ins k t) && isSemiRB u
 ===    {- induction -}
   (color (ins k t) == Blk || color u == Blk) && isSemiRB t && color t == Blk && isSemiRB u
 <==    {- propositional logic: ((P || Q) && R) <== (Q && R) -}
   color t == Blk && color u == Blk && isSemiRB t && isSemiRB u
 ===    {- definition of isSemiRB -}
   isSemiRB (R t x u)
 === qed
\end{code}

The property regarding isSemiRB and rotate  is

 1. (isIRB t || isSemiRB t) && isSemiRB u ==>
      isSemiRB (rotate t x u)
 2. semiRB t && (isIRB u || semiRB u) ==>
      isSemiRB (rotate t x u)

Whose proof we omit for now.

\begin{code}
infixr 0 ===, <==

(===) :: a -> List a -> List a
(===) = (:)

(<==) :: a -> List a -> List a
(<==) = (:)

qed :: List a
qed = []
\end{code}
