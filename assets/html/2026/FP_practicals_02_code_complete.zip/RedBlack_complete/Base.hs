{-# LANGUAGE StandaloneDeriving #-}
module Base where

type Nat = Int
type List a = [a]

data RBTree a = E | R (RBTree a) a (RBTree a)
                  | B (RBTree a) a (RBTree a)
data Color    = Red | Blk

color :: RBTree a -> Color
color E         = Blk
color (R _ _ _) = Red
color (B _ _ _) = Blk

insert :: Int -> RBTree Int -> RBTree Int
insert k t = blacken (ins k t)
  where blacken (R t x u) = B t x u
        blacken t = t

ins :: Int -> RBTree Int -> RBTree Int
ins k E = R E k E
ins k (R t x u) | k <  x = R (ins k t) x u
                | k == x = R t x u
                | k >  x = R t x (ins k u)
ins k (B t x u) | k <  x = rotate (ins k t) x u
                | k == x = B t x u
                | k >  x = rotate t x (ins k u)

rotate :: RBTree a -> a -> RBTree a -> RBTree a
rotate (R (R t x u) y v) z w = R (B t x u) y (B v z w)
rotate (R t x (R u y v)) z w = R (B t x u) y (B v z w)
rotate t x (R (R u y v) z w) = R (B t x u) y (B v z w)
rotate t x (R u y (R v z w)) = R (B t x u) y (B v z w)
rotate t x u = B t x u

-- tree construction and searching

build :: List Int -> RBTree Int
build = foldr insert E

search :: Int -> RBTree Int -> Bool
search _ E         = False
search x (R t y u) | x < y  = search x t
                   | x == y = True
                   | x > y  = search x u
search x (B t y u) | x < y  = search x t
                   | x == y = True
                   | x > y  = search x u

-- instance derivations

deriving instance Eq a => Eq (RBTree a)
deriving instance Show a => Show (RBTree a)
deriving instance Eq Color
deriving instance Show Color
