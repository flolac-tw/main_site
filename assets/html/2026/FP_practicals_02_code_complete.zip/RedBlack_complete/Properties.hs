module Properties where

-- Code adapted from Chris Okasaki,
--  Red-black trees in a functional setting.
--  Journal of Functional Programming, 9(4):471–477, 1999.

import Base

isRedBlackTree :: RBTree Int -> Bool
isRedBlackTree t = isSorted t && isBalanced t && isRB t

-- height

bheight :: RBTree a -> Nat
bheight E = 0
bheight (R t x u) = bheight t `max` bheight u
bheight (B t x u) = 1 + (bheight t `max` bheight u)

isBalanced :: RBTree a -> Bool
isBalanced E = True
isBalanced (R t x u) = bheight t == bheight u &&
                       isBalanced t && isBalanced u
isBalanced (B t x u) = bheight t == bheight u &&
                       isBalanced t && isBalanced u

-- sortedness

maxRBT :: RBTree Int -> Int
maxRBT E = minBound
maxRBT (R t x u) = x `max` maxRBT t `max` maxRBT u
maxRBT (B t x u) = x `max` maxRBT t `max` maxRBT u

minRBT :: RBTree Int -> Int
minRBT E = maxBound
minRBT (R t x u) = x `min` minRBT t `min` minRBT u
minRBT (B t x u) = x `min` minRBT t `min` minRBT u

isSorted :: RBTree Int -> Bool
isSorted E = True
isSorted (R t x u) = maxRBT t < x && x < minRBT u &&
                       isSorted t && isSorted u
isSorted (B t x u) = maxRBT t < x && x < minRBT u &&
                       isSorted t && isSorted u

-- colors

isSemiRB :: RBTree a -> Bool
isSemiRB E = True
isSemiRB (B t x u) = isSemiRB t && isSemiRB u
isSemiRB (R t x u) = (color t == Blk && color u == Blk) &&
                       isSemiRB t && isSemiRB u

isRB :: RBTree a -> Bool
isRB t = color t == Blk && isSemiRB t

  -- infrared

isIRB :: RBTree a -> Bool
isIRB E = True
isIRB (B t x u) = isSemiRB t && isSemiRB u
isIRB (R t x u) = (color t == Blk || color u == Blk) &&
                    isSemiRB t && isSemiRB u

-- checkable properties.

-- To test these properties, type for example,
--   > quickCheck propIsBalanced
-- in GHCi.
-- To see the inputs used in testing, use
--   > verboseCheck propIsBalanced

propIsBalanced :: [Int] -> Bool
propIsBalanced = isBalanced . build

propIsSorted :: [Int] -> Bool
propIsSorted = isSorted . build

propIsRB :: [Int] -> Bool
propIsRB = isRB . build

propIsRB' :: Int -> [Int] -> Bool   -- would be falisified
propIsRB' x xs = isRB . ins x . build $ xs

propIsIRB :: Int -> [Int] -> Bool
propIsIRB x xs = isIRB . ins x . build $ xs
