import Prelude ()
import MiniPrelude
import Monads

data Expr = Num Int | Neg Expr | Add Expr Expr
          | Var Name | Let Name Expr Expr
          | Div Expr Expr

type Name = String

-- Lists as environments:
--   type Env = List (Name, Int)

-- empty :: Env
-- empty = []
--
-- extend :: (Name, Int) -> Env -> Env
-- extend (x,v) env = (x,v) : env

-- The function
--   lookup :: Eq a => a -> List (a, b) -> Maybe b
-- is defined in GHC.List and imported here.

-- Functions as environments:

type Env = Name -> Maybe Int

empty :: Env
empty _ = Nothing

extend :: (Name, Int) -> Env -> Env
extend (x,v) env y | x == y    = Just v
                   | otherwise = env y

lookupEnv :: Name -> Env -> Maybe Int
lookupEnv x env = env x


evalA :: MonadReader Env m => Expr -> m Int
evalA (Num n) = return n
evalA (Neg e) = evalA e >>= \v ->
                return (negate v)
evalA (Add e0 e1) = evalA e0 >>= \v0 ->
                    evalA e1 >>= \v1 ->
                    return (v0+v1)
evalA (Var x) = ask >>= \env ->
                case lookupEnv x env of
                  Just v -> return v
evalA (Let x e0 e1) = evalA e0 >>= \v ->
                      local (extend (x,v)) (evalA e1)

  -- alternatively, using do-notation

evalA' :: MonadReader Env m => Expr -> m Int
evalA' (Num n) = return n
evalA' (Neg e) = do v <- evalA' e
                    return (negate v)
evalA' (Add e0 e1) = do v0 <- evalA' e0
                        v1 <- evalA' e1
                        return (v0+v1)
evalA' (Var x) = do env <- ask
                    case lookupEnv x env of
                        Just v -> return v
evalA' (Let x e0 e1) = do v <- evalA' e0
                          local (extend (x,v)) (evalA' e1)


evalC :: (MonadReader Env m, MonadFail m)
      => Expr -> m Int
evalC (Num n) = return n
evalC (Neg e) = evalC e >>= \v ->
                return (negate v)
evalC (Add e0 e1) = evalC e0 >>= \v0 ->
                    evalC e1 >>= \v1 ->
                    return (v0+v1)
evalC (Var x) = ask >>= \env ->
                case lookupEnv x env of
                  Just v -> return v
                  Nothing -> fail
evalC (Let x e0 e1) = evalC e0 >>= \v ->
                      local (extend (x,v)) (evalC e1)


data Err = DivByZero | VarNotFound Name
         | Overflow | Underflow
  deriving Show


evalE :: (MonadExcept Err m, MonadReader Env m)
      => Expr -> m Int
evalE (Num n) = return n
evalE (Neg e) = evalE e >>= \v ->
                return (negate v)
evalE (Add e0 e1) = evalE e0 >>= \v0 ->
                    evalE e1 >>= \v1 ->
                    return (v0+v1)
evalE (Div e0 e1) = evalE e1 >>= \v1 ->
                    if v1 == 0 then
                      throw DivByZero
                    else evalE e0 >>= \v0 ->
                         return (v0 `div` v1)
evalE (Var x) = ask >>= \env ->
                case lookupEnv x env of
                  Just v -> return v
                  Nothing -> throw (VarNotFound x)
evalE (Let x e0 e1) = evalE e0 >>= \v ->
                      local (extend (x,v)) (evalE e1)


   --- alternatively, using <$>, <*>, etc,
   --- and a function maybe :: b -> (a -> b) -> Maybe a -> b


evalE' :: (MonadExcept Err m, MonadReader Env m)
       => Expr -> m Int
evalE' (Num n) = return n
evalE' (Neg e) = negate <$> evalE' e
evalE' (Add e0 e1) = (+) <$> evalE' e0 <*> evalE' e1
evalE' (Div e0 e1) = div <$> evalE' e0 <*>
                         (evalE' e1 >>= \v1 ->
                           if v1 == 0 then throw DivByZero
                              else return v1)
evalE' (Var x) = (lookupEnv x <$> ask) >>=
                 maybe (throw (VarNotFound x)) return
evalE' (Let x e0 e1) = evalE' e0 >>= \v ->
                       local (extend (x,v)) (evalE' e1)


evalF :: (MonadReader Env m, MonadExcept Err m) => Expr -> m Int
evalF e = catchE (evalF' e) hdl
   where hdl Overflow  = return 32767
         hdl Underflow = return (-32768)
         hdl err       = throw err

evalF' :: (MonadReader Env m, MonadExcept Err m) => Expr -> m Int
evalF' (Num n) = return n
evalF' (Neg e) = evalF e >>= \v ->
                 return (negate v)
evalF' (Add e0 e1) = evalF e0 >>= \v0 ->
                     evalF e1 >>= \v1 ->
                     v0 `add` v1
evalF' (Div e0 e1) = evalF e1 >>= \v1 ->
                     if v1 == 0 then
                       throw DivByZero
                     else evalF e0 >>= \v0 ->
                          v0 `div'` v1
evalF' (Var x) = ask >>= \env ->
                 case lookupEnv x env of
                  Just v -> return v
                  Nothing -> throw (VarNotFound x)
evalF' (Let x e0 e1) = evalF e0 >>= \v ->
                       local (extend (x,v)) (evalF e1)

 -- "primitive" addition and division that raise
 -- overflow and underflow errors.

overflow :: Int -> Bool
overflow n = n > 32767

underflow :: Int -> Bool
underflow n = n < -32768

flowcheck :: MonadExcept Err m => Int -> m Int
flowcheck n | overflow n  = throw Overflow
            | underflow n = throw Underflow
            | otherwise   = return n

add :: MonadExcept Err m => Int -> Int -> m Int
add x y = flowcheck (x + y)

div' :: MonadExcept Err m => Int -> Int -> m Int
div' x y = flowcheck (x `div` y)


evalG :: (MonadState Int m, MonadExcept Err m, MonadReader Env m)
      => Expr -> m Int
evalG (Num n) = return n
evalG (Neg e) = evalG e >>= \v ->
                return (negate v)
evalG (Add e0 e1) = evalG e0  >>= \v0 ->
                    evalG e1  >>= \v1 ->
                    get       >>= \c  ->
                    put (1+c) >>= \() ->
                    return (v0+v1)
evalG (Div e0 e1) = evalG e1 >>= \v1 ->
                    if v1 == 0 then
                      throw DivByZero
                    else evalG e0 >>= \v0 ->
                         return (v0 `div` v1)
evalG (Var x) = ask >>= \env ->
                case lookupEnv x env of
                  Just v -> return v
                  Nothing -> throw (VarNotFound x)
evalG (Let x e0 e1) = evalG e0 >>= \v ->
                      local (extend (x,v)) (evalG e1)

tstExpr00 :: Expr
tstExpr00 = Let "x" (Num 3)
             (Add (Add (Var "x") (Let "x" (Num 4) (Var "x")))
                  (Neg (Var "x")))

tstExpr01 :: Expr
tstExpr01 = Let "x" (Add (Num 3) (Num 4))
             (Let "y" (Add (Var "x") (Neg (Num 1)))
                (Add (Add (Neg (Var "y")) (Var "x")) (Var "x")))


tstExpr02, tstExpr03 :: Expr

tstExpr02 = (Num 65536 `Add` Num 32768) `Div`
                (Num 1 `Add` Num 65536)

tstExpr03 = (Num 32768 `Div` Num 0) `Add` Num 32768
