{-# LANGUAGE FunctionalDependencies #-}
module Monads where

import Prelude ()
import MiniPrelude

{- Monad Classes -}

class Monad m => MonadFail m where
  fail  :: m a

class MonadFail m => MonadCatch m where
  catch :: m a -> m a -> m a

class Monad m => MonadExcept e m | m -> e where
  throw :: e -> m a
  catchE :: m a -> (e -> m a) -> m a

class Monad m => MonadState s m | m -> s where
  get :: m s
  put :: s -> m ()

class Monad m => MonadReader e m | m -> e where
  ask   :: m e
  local :: (e -> e) -> m a -> m a

class Monad m => MonadAlt m where
  (<|>)  :: m a -> m a -> m a

class (MonadFail m, MonadAlt m) => MonadNondet m where

assert :: MonadFail m => (a -> Bool) -> m a -> m a
assert p mx = do x <- mx
                 if p x then return x else fail

increment :: MonadState Int m => m Int
increment = do s <- get
               put (s+1)
               return s


{- Monad Instances -}

{- Reader -}

data Reader e a = Rdr (e -> a)

runReader :: Reader e a -> e -> a
runReader (Rdr f) = f

instance Monad (Reader e) where
  return x     = Rdr (\ env -> x)
  Rdr mx >>= f = Rdr (\ env -> runReader (f (mx env)) env)

instance MonadReader e (Reader e) where
 ask = Rdr (\ env -> env)
 local f mx = Rdr (\env -> runReader mx (f env))

-- Functor and Applicative instances

instance Functor (Reader e) where
  fmap = liftM

instance Applicative (Reader e) where
  pure  = return
  (<*>) = ap

{- Reader-Fail -}

data ReMaybe env a = RM (env -> Maybe a)

runReMaybe :: ReMaybe env a -> env -> Maybe a
runReMaybe (RM f) = f


instance Monad (ReMaybe env) where
  return x    = RM (\env -> Just x)
  RM mx >>= k = RM (\env -> case mx env of
                              Just x  -> runReMaybe (k x) env
                              Nothing -> Nothing)

instance MonadReader env (ReMaybe env) where
  ask = RM Just
  local f (RM mx) = RM (mx . f)

instance MonadFail (ReMaybe env) where
  fail = RM (const Nothing)

instance MonadCatch (ReMaybe env) where
  catch (RM f) hdl =
    RM (\env -> case f env of
                  Just x -> Just x
                  Nothing -> runReMaybe hdl env)


-- Functor and Applicative instances

instance Functor (ReMaybe env) where
  fmap = liftM

instance Applicative (ReMaybe env) where
  pure  = return
  (<*>) = ap

{- Reader-Except -}

data ReEx env err a = RE (env -> Except err a)

runReEx :: ReEx env err a -> env -> Except err a
runReEx (RE f) = f

data Except err a = Return a | Throw err
  deriving Show

instance Monad (ReEx env err) where
  return x    = RE (\env -> Return x)
  RE mx >>= k = RE (\env -> case mx env of
                              Return x  -> runReEx (k x) env
                              Throw err -> Throw err)

instance MonadReader env (ReEx env err) where
  ask = RE Return
  local f (RE mx) = RE (mx . f)

instance MonadExcept err (ReEx env err) where
  throw e = RE (\env -> Throw e)
  catchE (RE mx) hdl =
    RE (\env -> case mx env of
          Return x -> Return x
          Throw err -> runReEx (hdl err) env)

-- Functor and Applicative instances

instance Functor (ReEx env err) where
  fmap = liftM

instance Applicative (ReEx env err) where
  pure  = return
  (<*>) = ap

{- State -}

data State s a = ST (s -> (a, s))

runState :: State s a -> s -> (a, s)
runState (ST f) = f

instance Monad (State s) where
  return x = ST (\s -> (x,s))
  ST mx >>= k = ST (\s -> case mx s of
                           (y, s') -> runState (k y) s')
  -- ST mx >>= k = ST (\s -> let (y,s') = mx s
  --                             ST kf  = k y
  --                         in kf s')

instance MonadState s (State s) where
  get    = ST (\s -> (s,s))
  put s' = ST (\s -> ((),s'))


-- Functor and Applicative instances

instance Functor (State s) where
  fmap = liftM

instance Applicative (State s) where
  pure  = return
  (<*>) = ap

{- Reader-State -}

data StRe e s a = SR (e -> s -> (a, s))

runStRe :: StRe e s a -> e -> s -> (a, s)
runStRe (SR f) = f

instance Monad (StRe e s) where
  return x = SR (\e s -> (x,s))
  SR mx >>= k = SR (\e s -> let (y,s') = mx e s
                            in runStRe (k y) e s')

instance MonadState s (StRe e s) where
  get    = SR (\e s -> (s,s))
  put s' = SR (\e s -> ((),s'))

instance MonadReader e (StRe e s) where
  ask        = SR (\e s -> (e, s))
  local f mx = SR (\e s -> runStRe mx (f e) s)

-- Functor and Applicative instances

instance Functor (StRe e s) where
  fmap = liftM

instance Applicative (StRe e s) where
  pure  = return
  (<*>) = ap

{- State-Fail -}

data STE s a = STE (s -> Maybe (a, s))

instance Monad (STE s) where
  -- return x = STE (\s -> Just (x, s))
  return = pure
  STE mx >>= f =
    STE (\s -> case mx s of
           Nothing -> Nothing
           Just (x,s') -> case f x of
                            STE k -> k s')

instance MonadFail (STE s) where
 fail = STE (\s -> Nothing)

instance MonadState s (STE s) where
  get    = STE (\s -> Just (s,s))
  put s' = STE (\_ -> Just ((),s'))

-- Functor and Applicative instances

instance Functor (STE s) where
  fmap = liftM

instance Applicative (STE s) where
  pure x = STE (\s -> Just (x, s))
  (<*>) = ap

--
{- Reader-State-Except -}

data RSE env st err a = RSE (env -> st -> Except err (a, st))

runRSE :: RSE env st err a -> env -> st -> Except err (a, st)
runRSE (RSE f) = f

instance Monad (RSE env st err) where
  return x = RSE (\e s -> Return (x,s))
  RSE mx >>= k = RSE (\e s -> case mx e s of
                               Return (y,s') -> runRSE (k y) e s'
                               Throw err -> Throw err)

instance MonadState st (RSE env st err) where
  get    = RSE (\e s -> Return (s,s))
  put s' = RSE (\e s -> Return ((),s'))

instance MonadReader env (RSE env st err) where
  ask        = RSE (\e s -> Return (e, s))
  local f mx = RSE (\e s -> runRSE mx (f e) s)

instance MonadExcept err (RSE env st err) where
  throw e = RSE (\env s -> Throw e)
  catchE (RSE mx) hdl =
    RSE (\env s -> case mx env s of
           Return x -> Return x
           Throw err -> runRSE (hdl err) env s)

-- Functor and Applicative instances

instance Functor (RSE env st err) where
  fmap = liftM

instance Applicative (RSE env st err) where
  pure  = return
  (<*>) = ap
