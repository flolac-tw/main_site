Prerequisites
=============

- Python
- Python packages:
  + z3-solver
