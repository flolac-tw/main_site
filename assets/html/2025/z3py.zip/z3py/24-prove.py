#!/usr/bin/env python3

from z3 import *

p, q = Bools('p q')
demorgan = And(p, q) == Not(Or(Not(p), Not(q)))
print (demorgan)

print("Check satisfiability of the negation...")
solve(Not(demorgan))

print ("Proving demorgan...")
prove(demorgan)
