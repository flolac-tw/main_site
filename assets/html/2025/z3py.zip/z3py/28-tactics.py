#!/usr/bin/env python3

from z3 import *

describe_tactics()
