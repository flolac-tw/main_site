#!/usr/bin/env python3

from z3 import *

# Create to bit-vectors of size 32
x, y = BitVecs('x y', 32)
solve(x >> 2 == 3)
solve(x << 2 == 3)
solve(x << 2 == 24)
solve(x >> 2 < 0)
solve(LShR(x, 2) < 0)
