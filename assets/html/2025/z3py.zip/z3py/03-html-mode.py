#!/usr/bin/env python3

from z3 import *

x = Int('x')
y = Int('y')
set_option(html_mode=True)
print (And(x**2 + y**2 >= 1, x > 2))
set_option(html_mode=False)
print (And(x**2 + y**2 >= 1, x > 2))
