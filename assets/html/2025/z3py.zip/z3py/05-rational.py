#!/usr/bin/env python3

from z3 import *

x = Real('x')
y = Real('y')
solve(x**2 + y**2 > 3, x**3 + y < 5)
solve(2 * x == 3)
