module Arith
  ( Expr(..)
  , isValue
  , subst
  , redex
  , reduce
  ) where

data Expr =
    ILit Integer
  | Plus Expr Expr
  | Times Expr Expr
  | BLit Bool
  | Equ Expr Expr
  | If Expr Expr Expr
  | Var String
  | Let String Expr Expr
  deriving (Show, Eq)

isValue :: Expr -> Bool
isValue (ILit _) = True
isValue (BLit _) = True
isValue _        = False

redex :: Expr -> [Expr]
redex (Plus (ILit n) (ILit m))  = [ILit (n + m)]
redex (Times (ILit n) (ILit m)) = [ILit (n * m)]
redex (Equ (ILit n) (ILit m))   = [BLit (n == m)]
redex (Equ (BLit b1) (BLit b2)) = [BLit (b1 == b2)]
redex (If (BLit True) e1 e2)    = [e1]
redex (If (BLit False) e1 e2)   = [e2]
redex (Let x v e) | isValue v   = case subst e v x of
                                    Just e' -> [e']
                                    Nothing -> []
redex _                         = []

reduce :: Expr -> [Expr]
reduce e = redex e ++
           case e of
             ILit _      -> []
             Plus e1 e2  -> [ Plus e1' e2   | e1' <- reduce e1 ] ++
                            [ Plus e1  e2'  | isValue e1, e2' <- reduce e2 ]
             Times e1 e2 -> [ Times e1' e2  | e1' <- reduce e1 ] ++
                            [ Times e1  e2' | isValue e1, e2' <- reduce e2 ]
             BLit _      -> []
             Equ e1 e2   -> [ Equ e1' e2    | e1' <- reduce e1 ] ++
                            [ Equ e1  e2'   | isValue e1, e2' <- reduce e2 ]
             If e1 e2 e3 -> [ If e1' e2 e3 | e1' <- reduce e1 ]
             Var _       -> []
             Let x e1 e2 -> [ Let x e1' e2 | e1' <- reduce e1 ]

{-|
  The `subst` function substitutes the given value for the designated variable
  in an expression. More precisely,
  * The expression`subst e v x` means substitute `v` for `x` in `e`
  * The `subst` function is limited to the case where
    `v` is either an `ILit` or a `BLit`.
-}
subst :: Expr -> Expr -> String -> Maybe Expr
subst e v x | isValue v = Just (subst' e v x)
subst _ _ _             = Nothing

subst' :: Expr -> Expr -> String -> Expr
subst' (ILit n)      v x = ILit n
subst' (Plus e1 e2)  v x = Plus (subst' e1 v x) (subst' e2 v x)
subst' (Times e1 e2) v x = Times (subst' e1 v x) (subst' e2 v x)
subst' (BLit b)      v x = BLit b
subst' (Equ e1 e2)   v x = Equ (subst' e1 v x) (subst' e2 v x)
subst' (If e1 e2 e3) v x = If (subst' e1 v x) (subst' e2 v x) (subst' e3 v x)
subst' (Var y)       v x
  | y == x               = v
  | otherwise            = Var y
subst' (Let y e1 e2) v x
  | y == x               = Let y (subst' e1 v x) e2
  | otherwise            = Let y (subst' e1 v x) (subst' e2 v x)
