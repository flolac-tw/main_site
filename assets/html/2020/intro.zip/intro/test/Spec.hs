
import Test.Hspec
import Control.Monad

import Arith

test_subst :: SpecWith (Arg Expectation)
test_subst =
  describe "The ‘subst’ function" $ do
    it "fails when substituting non-literals" $
      subst (ILit 0) (Plus (ILit 0) (ILit 0)) "x"
            `shouldBe`
            Nothing
    it "substitutes new value for matching variables" $ do
      subst (Var "x") (ILit 5) "x"
            `shouldBe`
            Just (ILit 5)
      subst (Var "y") (ILit 5) "x"
            `shouldBe`
            Just (Var "y")
    it "recurs structurally" $ do
      subst (ILit 7) (ILit 5) "x"
            `shouldBe`
            Just (ILit 7)
      subst (Plus (ILit 8) (Times (Var "x") (Var "x"))) (ILit 5) "x"
            `shouldBe`
            Just (Plus (ILit 8) (Times (ILit 5) (ILit 5)))
      subst (Equ (Var "x") (ILit 5)) (ILit 7) "x"
            `shouldBe`
            Just (Equ (ILit 7) (ILit 5))
      subst (Plus (ILit 8) (If (Equ (Var "x") (ILit 5))
                               (ILit 99)
                               (Var "x")))
            (ILit 5) "x"
            `shouldBe`
            Just (Plus (ILit 8) (If (Equ (ILit 5) (ILit 5))
                                    (ILit 99)
                                    (ILit 5)))
      subst (Let "x" (Var "x") (ILit 8)) (ILit 5) "x"
            `shouldBe`
            Just (Let "x" (ILit 5) (ILit 8))
    it "shadowed by new let bindings" $
      subst (Let "x" (ILit 8) (Var "x")) (ILit 5) "x"
            `shouldBe`
            Just (Let "x" (ILit 8) (Var "x"))
    it "recurs through non-shadowing let expressions" $
      subst (Let "y" (ILit 8) (Var "x")) (ILit 5) "x"
            `shouldBe`
            Just (Let "y" (ILit 8) (ILit 5))

data RedexConfig = RedexConfig { name :: String
                               , relation :: Expr -> [Expr]
                               , recurs :: Bool }

test_redexes :: RedexConfig -> SpecWith (Arg Expectation)
test_redexes RedexConfig{name = name, relation = redex, recurs = willRecur} = do
  describe ("‘" ++ name ++ "’ should include") $ do
    it "basic arithmetic operations" $ do
      redex (Plus (ILit 3) (ILit 8))
        `shouldBe`
        [ILit 11]
      redex (Times (ILit 3) (ILit 8))
        `shouldBe`
        [ILit 24]
      redex (Equ (ILit 3) (ILit 8))
        `shouldBe`
        [BLit False]
      redex (Equ (ILit 7) (ILit 7))
        `shouldBe`
        [BLit True]
      redex (Equ (BLit False) (BLit False))
        `shouldBe`
        [BLit True]
    it "conditional branching" $ do
      redex (If (BLit True) (ILit 5) (Times (ILit 2) (ILit 77)))
        `shouldBe`
        [ILit 5]
      redex (If (BLit False) (ILit 5) (Times (ILit 2) (ILit 77)))
        `shouldBe`
        [Times (ILit 2) (ILit 77)]
    it "let substitution" $ do
      redex (Let "x" (ILit 3)
                 (Let "y" (ILit 4)
                      (Plus (Times (Var "y") (Var "y"))
                            (Times (Var "x") (Var "x")))))
        `shouldBe`
        [Let "y" (ILit 4)
             (Plus (Times (Var "y") (Var "y"))
                   (Times (ILit 3) (ILit 3)))]

  describe ("‘" ++ name ++ "’ specifies") $
    it "call-by-value semantics" $ do
      redex (Let "x" (Var "y") (Var "x"))
        `shouldBe`
        []
      unless willRecur $
        redex (Let "x" (Plus (ILit 5) (ILit 0)) (Var "x"))
          `shouldBe`
          []

test_reduce :: SpecWith (Arg Expectation)
test_reduce = do
  describe "‘reduce’ includes ‘redex’" $
    test_redexes $ RedexConfig{ name = "reduce", relation = reduce, recurs = True}
  describe "‘reduce’ specifies left-to-right call-by-value evaluation strategy" $ do
    it "covers values and stuck terms" $ do
      reduce (ILit 5)
        `shouldBe`
        []
      reduce (BLit False)
        `shouldBe`
        []
      reduce (Var "z")
        `shouldBe`
        []
      reduce (Plus (ILit 5) (Var "s"))
        `shouldBe`
        []
    it "evaluate subterms from left to right" $ do
      reduce (Plus (ILit 5) (ILit 13))
        `shouldBe`
        [ILit 18]
      reduce (Plus (Times (ILit 5) (ILit 2))
                   (Plus (ILit 5) (ILit 2)))
        `shouldBe`
        [Plus (ILit 10)
              (Plus (ILit 5) (ILit 2))]
      reduce (Plus (ILit 10)
                   (Plus (ILit 5) (ILit 2)))
        `shouldBe`
        [Plus (ILit 10) (ILit 7)]
      reduce (Times (ILit 5) (ILit 13))
        `shouldBe`
        [ILit 65]
      reduce (Times (Times (ILit 5) (ILit 2))
                   (Plus (ILit 5) (ILit 2)))
        `shouldBe`
        [Times (ILit 10)
              (Plus (ILit 5) (ILit 2))]
      reduce (Times (ILit 10)
                   (Plus (ILit 5) (ILit 2)))
        `shouldBe`
        [Times (ILit 10) (ILit 7)]
      reduce (Equ (Times (ILit 6) (ILit 4))
                  (Times (ILit 8) (ILit 3)))
        `shouldBe`
        [Equ (ILit 24) (Times (ILit 8) (ILit 3))]
      reduce (Equ (ILit 24) (Times (ILit 8) (ILit 3)))
        `shouldBe`
        [Equ (ILit 24) (ILit 24)]
    it "evaluate ‘if’ properly" $ do
      reduce (If (Equ (ILit 5) (ILit 8))
                 (Plus (ILit 2) (ILit 3))
                 (Times (ILit 4) (ILit 5)))
        `shouldBe`
        [If (BLit False)
            (Plus (ILit 2) (ILit 3))
            (Times (ILit 4) (ILit 5))]
      reduce (If (Equ (ILit 3) (ILit 3))
                 (Plus (ILit 2) (ILit 3))
                 (Times (ILit 4) (ILit 5)))
        `shouldBe`
        [If (BLit True)
            (Plus (ILit 2) (ILit 3))
            (Times (ILit 4) (ILit 5))]
    it "evaluate ‘let’ satisfying the by-value strategy" $ do
      reduce (Let "x" (ILit 8) (Var "x"))
        `shouldBe`
        [ILit 8]
      reduce (Let "x" (Equ (BLit False) (BLit True)) (Var "x"))
        `shouldBe`
        [Let "x" (BLit False) (Var "x")]

main =
  hspec $ do
    test_subst
    test_redexes $ RedexConfig{ name = "redex", relation = redex, recurs = False}
    test_reduce
