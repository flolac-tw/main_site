# Programming Language Theory: Introduction

This is the Haskell implementation of the arithmetic
language introduced on Aug 10. For more information,
please check the course website.

## Usage

To compile the file, type `stack build`. To enter REPL to
experiment with the definitions, type `stack ghci`.

To run the test suite, use `stack test`.

## Directory Structure

- `src/Arith.hs`: This file contains the data type definition
    of terms in the arithmetic language as well as an
    implementation of the reduction relation. Please check the
    functions `redex` and `reduce`.

- `test/Spec.hs`: This file contains various tests for
    `redex`, `reduce` and `subst` functions.
